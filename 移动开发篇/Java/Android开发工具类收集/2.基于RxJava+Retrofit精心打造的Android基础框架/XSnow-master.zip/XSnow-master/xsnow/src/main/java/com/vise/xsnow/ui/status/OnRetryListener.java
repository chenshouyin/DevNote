package com.vise.xsnow.ui.status;

/**
 * @Description: 重新加载监听
 * @author: <a href="http://xiaoyaoyou1212.360doc.com">DAWI</a>
 * @date: 2017-03-08 15:47
 */
public interface OnRetryListener {
    void onRetry();
}
